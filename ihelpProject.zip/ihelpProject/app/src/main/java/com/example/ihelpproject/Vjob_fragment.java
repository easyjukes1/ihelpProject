package com.example.ihelpproject;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class Vjob_fragment extends Fragment {
    View view;
    private List<VcharityJobs> listJobs;

    public Vjob_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_vjob, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.jobRv);

        RecyclerViewVJobsAdapter recyclerAdapter = new RecyclerViewVJobsAdapter(getContext(), listJobs);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerAdapter);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listJobs = new ArrayList<>();
        listJobs.add(new VcharityJobs("tkiyet umali", "khalda", "aytam", R.drawable.org2));
        listJobs.add(new VcharityJobs("king hussein cancer center", "downtown", "teaching", R.drawable.org3));
        listJobs.add(new VcharityJobs("etc", "aqaba", "Gardening", R.drawable.org1_icon));



    }

}
