package com.example.ihelpproject;

public class charityVolunteers {
    private String VolunteerName;
    private String jobType;
    private int img_charityVolunteer;

    public String getVolunteerName() {
        return VolunteerName;
    }

    public void setVolunteerName(String volunteerName) {
        VolunteerName = volunteerName;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public int getImg_charityVolunteer() {
        return img_charityVolunteer;
    }

    public void setImg_charityVolunteer(int img_charityVolunteer) {
        this.img_charityVolunteer = img_charityVolunteer;
    }

    public charityVolunteers(String volunteerName, String jobType, int img_charityVolunteer) {
        VolunteerName = volunteerName;
        this.jobType = jobType;
        this.img_charityVolunteer = img_charityVolunteer;
    }



}