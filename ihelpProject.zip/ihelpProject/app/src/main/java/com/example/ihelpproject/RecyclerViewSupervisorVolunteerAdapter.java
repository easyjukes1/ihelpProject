package com.example.ihelpproject;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RecyclerViewSupervisorVolunteerAdapter extends RecyclerView.Adapter<RecyclerViewSupervisorVolunteerAdapter.myViewHolder> {

    private Context context;
    private List<Supervisor_volunteers> supervisorVolunteersData;

    public RecyclerViewSupervisorVolunteerAdapter(Context context, List<Supervisor_volunteers> supervisorVolunteersData) {
        this.context = context;
        this.supervisorVolunteersData = supervisorVolunteersData;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        view = LayoutInflater.from(context).inflate(R.layout.item_supervisor_volunteer, viewGroup, false);
        myViewHolder myViewHolder = new myViewHolder(view);
        return myViewHolder;

    }
//text1.setText(String.valueOf(productCalories));
    @Override
    public void onBindViewHolder(@NonNull myViewHolder myViewHolder, int i) {
        myViewHolder.tv_VolunteerName.setText(supervisorVolunteersData.get(i).getVolunteerName());
        myViewHolder.idNumber.setText(String.valueOf(supervisorVolunteersData.get(i).getIdNumber()));
        myViewHolder.img_Volunteer.setImageResource(supervisorVolunteersData.get(i).getImg_Volunteer());
        myViewHolder.charityName.setText(supervisorVolunteersData.get(i).getCharityName());
    }

    @Override
    public int getItemCount() {
        return supervisorVolunteersData.size();
    }

    public static class myViewHolder extends RecyclerView.ViewHolder {
        private ImageView img_Volunteer;
        private TextView tv_VolunteerName;
        private TextView idNumber;
        private TextView charityName;


        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            img_Volunteer = itemView.findViewById(R.id.img_Volunteer);
            tv_VolunteerName = itemView.findViewById(R.id.VolunteerName);
            idNumber = itemView.findViewById(R.id.idNumber);
            charityName = itemView.findViewById(R.id.charityName);

        }
    }
}
