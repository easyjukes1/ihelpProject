package com.example.ihelpproject;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class RecyclerViewVJobsAdapter extends RecyclerView.Adapter<RecyclerViewVJobsAdapter.myViewHolder> {

    private Context context;
    private List<VcharityJobs> vcharityJobsData;

    public RecyclerViewVJobsAdapter(Context context, List<VcharityJobs> vcharityJobsData) {
        this.context = context;
        this.vcharityJobsData = vcharityJobsData;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        view = LayoutInflater.from(context).inflate(R.layout.item_vcharityjob, viewGroup, false);
        myViewHolder myViewHolder = new myViewHolder(view);
        return myViewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder myViewHolder, int i) {
        myViewHolder.tv_charityName.setText(vcharityJobsData.get(i).getCharityName());
        myViewHolder.tv_jobCharity.setText(vcharityJobsData.get(i).getCharityType());
        myViewHolder.tv_charityAddress.setText(vcharityJobsData.get(i).getCharityAddress());
        myViewHolder.iv_jobImage.setImageResource(vcharityJobsData.get(i).getPhoto());
        myViewHolder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent i = new Intent(context, volunteerCharityJobs.class);
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return vcharityJobsData.size();
    }

    public static class myViewHolder extends RecyclerView.ViewHolder {
        private ImageView iv_jobImage;
        private TextView tv_charityName;
        private TextView tv_jobCharity;
        private TextView tv_charityAddress;
        private LinearLayout parentLayout;


        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_charityName = itemView.findViewById(R.id.charityName);
            tv_jobCharity = itemView.findViewById(R.id.jobCharity);
            tv_charityAddress = itemView.findViewById(R.id.charityAddress);
            iv_jobImage = itemView.findViewById(R.id.imgCharityJobs);
            parentLayout = itemView.findViewById(R.id.layoutJob);
        }
    }
}
