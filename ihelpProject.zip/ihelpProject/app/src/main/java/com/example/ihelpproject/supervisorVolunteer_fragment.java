package com.example.ihelpproject;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class supervisorVolunteer_fragment extends Fragment {
    View view;
    private List<Supervisor_volunteers>   listSupervisorVolunteers;


    public supervisorVolunteer_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_supervisorvolunteers, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.VolunteerRv);

        RecyclerViewSupervisorVolunteerAdapter recyclerAdapter = new  RecyclerViewSupervisorVolunteerAdapter(getContext(),listSupervisorVolunteers);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerAdapter);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        listSupervisorVolunteers = new ArrayList<>();
        listSupervisorVolunteers.add(new Supervisor_volunteers("omar shashaa",201510210,"tkiyet umali",R.drawable.male2_icon));
        listSupervisorVolunteers.add(new Supervisor_volunteers("samiha",2015143210,"king hussein cancer center",R.drawable.female_icon));
        listSupervisorVolunteers.add(new Supervisor_volunteers("mwafg",201510777,"etc",R.drawable.male2_icon));





    }
}
