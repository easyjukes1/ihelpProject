package com.example.ihelpproject;



import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;



public class RegisterCharityFragment extends Fragment {
    private FirebaseAuth mAuth;
    EditText et_name, et_phonenumber1,et_email,et_username,et_password,et_address;
    View view;
    Button btn_create;
    FirebaseDatabase database;
    DatabaseReference myRef;
    Charity charityUser;


    public RegisterCharityFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_register_charity, container, false);
      mAuth = FirebaseAuth.getInstance();
        et_address = view.findViewById(R.id.et_address);
        et_phonenumber1 = view.findViewById(R.id.et_phonenumber);
        et_name = view.findViewById(R.id.et_name);
        et_email = view.findViewById(R.id.et_email);
        et_password = view.findViewById(R.id.et_password);
        et_username = view.findViewById(R.id.et_username);
        btn_create = view.findViewById(R.id.btn_create);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("charityUser");

        btn_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email= et_email.getText().toString();
                String password = et_password.getText().toString();
                String name =et_name.getText().toString();
                final String username=et_username.getText().toString();
                String address = et_address.getText().toString();
                //String phoneNumber= et_phonenumber1.getText().toString();
                charityUser= new Charity(name,address,email,password,"5");
                myRef.setValue(charityUser);

              mAuth.createUserWithEmailAndPassword(email,password)
                      .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {

                          @Override
                          public void onComplete(@NonNull Task<AuthResult> task) {
                              FirebaseDatabase.getInstance().getReference("charityUsers")
                              .child(mAuth.getCurrentUser().getUid())
                              .setValue(charityUser).addOnCompleteListener(new OnCompleteListener<Void>() {

                                  @Override
                                  public void onComplete(@NonNull Task<Void> task) {
                                     if(task.isSuccessful()) {
                                         Toast.makeText(getActivity(),"success",Toast.LENGTH_SHORT).show();
                                         Intent i = new Intent(getActivity(), LoginActivity.class);
                                         startActivity(i);
                                     }//end if
                                     else {
                                         //if the email is already registered //notworking !
                                         if(task.getException() instanceof FirebaseAuthUserCollisionException)
                                             Toast.makeText(getActivity(),"email is already exists ",Toast.LENGTH_SHORT).show();

                                     }
                                       }
                              });
                          }
                      });


                            }
                        });


        return view;

    }


}

