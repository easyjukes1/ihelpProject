package com.example.ihelpproject;

public class Student extends Volunteers {

    private int Id;
    private String SuperVisor;

    public Student(String name, String email, String username, String password, int age, String address, int phonenumber) {
        super(name, email, username, password, age, address, phonenumber);
    }

    public Student(String name, String email, String username, String password, int age, String address, int phonenumber, int id, String superVisor) {
        super(name, email, username, password, age, address, phonenumber);
        Id = id;
        SuperVisor = superVisor;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getSuperVisor() {
        return SuperVisor;
    }

    public void setSuperVisor(String superVisor) {
        SuperVisor = superVisor;
    }


}
