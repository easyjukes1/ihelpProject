package com.example.ihelpproject;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class createCharityAccActivity extends AppCompatActivity {
    Button btn_create;
    private FirebaseAuth mAuth;
    EditText et_name, et_phonenumber1,et_email,et_username,et_password,et_address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_register_charity);

        mAuth = FirebaseAuth.getInstance();
        et_address = findViewById(R.id.et_address);
        et_phonenumber1 =findViewById(R.id.et_phonenumber);
        et_name = findViewById(R.id.et_name);
        et_email =findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);
        et_username = findViewById(R.id.et_username);
        btn_create = findViewById(R.id.btn_create);



        final String email = et_email.getText().toString();
        final String password = et_password.getText().toString();

        btn_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                mAuth.createUserWithEmailAndPassword(email,password)
                        .addOnCompleteListener(createCharityAccActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {


                            }
                        });


            }
        });



    }

}

