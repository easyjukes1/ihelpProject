package com.example.ihelpproject;

public class CharityAddJob {
   private  String id;
    private String jobTitle;
    private String briefDescription;
    private String description;

    public CharityAddJob(String id, String jobTitle, String briefDescription, String description) {
        this.id = id;
        this.jobTitle = jobTitle;
        this.briefDescription = briefDescription;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getBriefDescription() {
        return briefDescription;
    }

    public void setBriefDescription(String briefDescription) {
        this.briefDescription = briefDescription;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
