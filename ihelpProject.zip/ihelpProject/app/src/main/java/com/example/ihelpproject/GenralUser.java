package com.example.ihelpproject;

public class GenralUser extends Volunteers {

    public GenralUser(String name, String email, String username, String password, int age, String address, int phonenumber) {
        super(name, email, username, password, age, address, phonenumber);
    }
}
