package com.example.ihelpproject;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class charityJobs_fragment extends Fragment {
    View view;
    private List<charityJobs>   listCharityJobs;
    FloatingActionButton addFAb;


    public charityJobs_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_charityjob, container, false);
        addFAb =view.findViewById(R.id.fab_add);

        addFAb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), CharityAddJobActivity.class);
                startActivity(i);

            }
        });


        RecyclerView recyclerView = view.findViewById(R.id.jobRv);
        RecyclerViewCharityJobsAdapter recyclerAdapter = new RecyclerViewCharityJobsAdapter(getContext(),listCharityJobs);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        recyclerView.setAdapter(recyclerAdapter);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        listCharityJobs = new ArrayList<>();
        listCharityJobs.add(new charityJobs("teaching in madaba", "teaching", "madaba", R.drawable.job1_icon));
        listCharityJobs.add(new charityJobs("Gardening in khalda", "Gardening", "khalda", R.drawable.job2_icon));
        listCharityJobs.add(new charityJobs("event in orphanage center", "help", "aqaba", R.drawable.job3));



    }
}
